import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';

class CreateTableTemoin {
  static Database? _db;

  static Database get db {
    if (_db == null) throw Exception('Base de données non initialisée');
    return _db!;
  }

  static Future<void> init() async {
    if (!kIsWeb &&
        (defaultTargetPlatform == TargetPlatform.linux ||
         defaultTargetPlatform == TargetPlatform.windows)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    final dbPath = await getDatabasesPath();

    _db = await openDatabase(
      join(dbPath, 'mon_app.db'),
      version: 2,                         // ← version incrémentée

      onCreate: (db, version) async {
        await _createInfoPersoTemoin(db);
      },

      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          // Migration v1 → v2 : ajout colonne img_temoin
          await db.execute(
            'ALTER TABLE info_perso_temoin ADD COLUMN img_temoin TEXT'
          );
        }
      },

      onOpen: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  static Future<void> _createInfoPersoTemoin(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS info_perso_temoin (
        id             TEXT    PRIMARY KEY,
        nom            TEXT    NOT NULL,
        prenom         TEXT    NOT NULL,
        date_naissance TEXT,
        departement    TEXT,
        region         TEXT,
        img_temoin     TEXT,
        date_creation  TEXT    NOT NULL
      )
    ''');
  }
}
